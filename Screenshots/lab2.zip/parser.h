#pragma once

using namespace std;
#include "token.h"
#include <vector>

class Parser
{
private:
    vector<Token> tokens;
    unsigned int index = 0;

public:
    void match(TokenType type)
    {
        if (tokens.at(index).getType() == type)
        {
            index++;
        }
        else
        {
            throw tokens.at(index);
        }
    }

    Parser(const vector<Token> &tokens) : tokens(tokens)
    {
    }

    void parse()
    {
        parseScheme();
    }

    //scheme -> ID LEFT_PAREN ID idList RIGHT_PAREN
    void parseScheme()
    {
        match(ID);
        match(LEFT_PAREN);
        match(ID);
        parseIdList();
        match(RIGHT_PAREN);
    }

    //idList -> COMMA ID idList | lambda
    void parseIdList()
    {
        if (tokens.at(index).getType() == TokenType::COMMA)
        {
            match(TokenType::COMMA);
            match(TokenType::ID);
            parseIdList();
        }
        else
        {
            return;
        }
    }
};