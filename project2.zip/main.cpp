#include <iostream>
#include <istream>
#include <fstream>
#include <vector>
#include <sstream>
#include "token.h"
#include "scanner.h"
#include "parser.h"
#include "predicate.h"
#include "parameter.h"
#include "datalogProgram.h"

int main(int argc, char *argv[])
{

    if (argc != 2)
    {
        return 1;
    }

    string inputFileName = argv[1];
    ifstream input(inputFileName);
    int realTokenCount = 0;
    vector<Token> tokens;
    if (!input)
    {
        throw runtime_error("Could not open file");
    }
    stringstream buffer;
    buffer << input.rdbuf();
    ofstream outfile;
    string inputString = buffer.str();

    Scanner scanner(inputString);

    while (fileReadCompleted == false)
    {

        realTokenCount++;

        Token currToken = scanner.scanToken();
        if (currToken.getType() != TokenType::COMMENT)
        {
            tokens.push_back(currToken);
        }
    }
    // CHANGE LATER!!! ONLY HERE TO GET RID OF EOF IN TESTS PROJECT 2
    // tokens.pop_back();

    // Scanner scanner(",,,");

    // vector<Token> tokens = {
    //     Token("Ned", ID, 2),
    //     Token("(", LEFT_PAREN, 2),
    //     Token("Swag", ID, 2),
    //     Token(",", COMMA, 2),
    //     Token("Johanna", ID, 2),
    //     Token(")", RIGHT_PAREN, 2)};
    // Token("", END_OF_FILE, 2)

    // Parser p = Parser(tokens);
    // p.match(ID);
    // p.match(LEFT_PAREN);
    // p.match(ID); // intentional error
    // p.match(RIGHT_PAREN);

    // tokens.push_back(Token("Schemes", TokenType::SCHEMES, 1));

    Parser parser(tokens);

    try
    {
        parser.parse();
        datalogProgram dp = parser.getDatalogProgram();
        cout << "Success!" << endl;
        cout << dp.toString();
    }

    catch (Token errorToken)
    {
        cout << "Failure!" << endl
             << errorToken.toString();
    }
    // cout << endl
    //      << endl;

    // for (unsigned int i = 0; i < tokens.size(); i++)
    // {
    //     cout << tokens.at(i).toString();
    //     cout << endl;
    // }

    // cout << "Total Tokens = " << realTokenCount << endl;

    return 0;
}