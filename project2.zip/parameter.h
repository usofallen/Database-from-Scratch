#pragma once
#include <string>
#include <sstream>
using namespace std;

class Parameter
{
public:
    string data;
    Parameter(const string &data) : data(data)
    {
    }
    Parameter()
    {
    }

    Parameter getParameters()
    {
        return data;
    }
    void setValue(string value)
    {
        data = value;
    }
    string getValue()
    {
        return data;
    }

    string toString()
    {
        stringstream ss;
        ss << data;
        return ss.str();
    }
};