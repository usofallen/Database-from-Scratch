#pragma once
#include "Relation.h"
//#include "Interpreter.h"
#include <map>

// AT 2nd recorded lab session 6:00 minutes
class Database
{
private:
    map<string, Relation> dataMap;

public:
    string toString()
    {
        stringstream out;
        for (pair<string, Relation> relationEntry : dataMap)
        {
            out << relationEntry.first;
            out << endl;
            out << relationEntry.second.toString();
        }

        return out.str();
    }

    Relation &getRelationByReference(string relationName)
    {
        return dataMap.at(relationName);
    }

    Relation getRelationCopy(string relationName)
    {
        return dataMap.at(relationName);
    }

    void insert(Relation r)
    {
        dataMap.insert({r.getName(), r});
    }

    unsigned int numTuples()
    {
        unsigned int count = 0;
        for (auto p : dataMap)
        {
            count += p.second.size();
        }
        return count;
    }

    Relation evaluateQuery(Predicate query)
    {
        Relation realRelation = getRelationCopy(query.getName());

        for (unsigned int i = 0; i < query.getParameters().size(); i++)
        {
            Parameter swagParameter = query.getParameters().at(i);

            if (swagParameter.at(0) == '\'')
            {
                realRelation = realRelation.select(i, swagParameter.getValue());
            }

            // it must be an ID
            else
            {
                for (unsigned int j = i; j < query.getParameters().size(); j++)
                {
                    if (isalpha(query.getParameters().at(j).at(0)))
                    {
                        realRelation = realRelation.select(i, j);
                    }
                }
            }
        }

        // use project to get rid of extra columns
        vector<int> newSchemePositions;
        for (unsigned int i = 0; i < query.getParameters().size(); i++)
        {
            if (isalpha(query.getParameters().at(i).at(0)))
            {
                newSchemePositions.push_back(i);
            }
        }
        realRelation = realRelation.project(newSchemePositions);

        vector<string> newSchemePositionStrings;
        for (unsigned int i = 0; i < query.getParameters().size(); i++)
        {
            if (isalpha(query.getParameters().at(i).at(0)))
            {
                newSchemePositionStrings.push_back(query.getParameters().at(i).getValue());
            }
        }

        Scheme newScheme(newSchemePositionStrings);

        realRelation = realRelation.rename(newScheme);

        vector<int> newTuplePositions;
        for (unsigned int i = 0; i < realRelation.getScheme().size(); i++)
        {
            bool alreadyThere = false;

            // loop through new tuple positions
            for (unsigned int j = 0; j < newTuplePositions.size(); j++)
            {
                string positionValue = realRelation.getScheme().at(newTuplePositions.at(j));

                if (positionValue == realRelation.getScheme().at(i))
                {
                    alreadyThere = true;
                    break;
                }
            }

            if (alreadyThere)
            {
                newTuplePositions.push_back(i);
            }
        }

        // realRelation = realRelation.project(newTuplePositions);

        return realRelation;
    }
};