#pragma once

#include <string>
#include <sstream>
#include <iostream>
#include <vector>
#include <sstream>
#include <set>
#include "Scheme.h"
#include "Tuple.h"
using namespace std;

class Relation
{

private:
    string name;
    Scheme scheme;
    set<Tuple> tuples;

public:
    Relation(const string &name, const Scheme &scheme) : name(name), scheme(scheme) {}
    Relation(const string &name, const Scheme &scheme, set<Tuple> &tuples) : name(name), scheme(scheme), tuples(tuples) {}
    Relation(const string &name, set<Tuple> &tuples) : name(name), tuples(tuples) {}
    Relation() {}

    // Getters & Setters vvvvvvvv
    const string &getName() const
    {
        return name;
    }

    void setName(const string &name)
    {
        Relation::name = name;
    }

    const Scheme &getScheme() const
    {
        return scheme;
    }

    void setScheme(const Scheme &scheme)
    {
        Relation::scheme = scheme;
    }
    // Getters & Setters ^^^^^^^

    bool addTuple(const Tuple &tuple) // if the tuple was not in the set this returns true, otherwise, false
    {
        return tuples.insert(tuple).second;
    }

    string toString() const
    {
        stringstream out;
        for (Tuple tuple : tuples)
        {
            if (tuple.size() != 0)
            {
                out << "  " << tuple.toString(scheme) << endl;
            }
        }

        return out.str();
    }

    Relation select(int index, const string &value) const
    {
        Relation output(name, scheme);
        for (auto &tuple : tuples)
        {
            if (tuple.at(index) == value)
            {
                output.addTuple(tuple);
            }
        }
        return output;
    }

    // how to do the version of select where it takes in two indexes. ??
    Relation select(unsigned int index1, unsigned int index2)
    {
        Relation output(name, scheme);
        for (auto &tuple : tuples)
        {
            if (tuple.at(index1) == tuple.at(index2)) // CHECK FOR BUGSSS!!
            {
                output.addTuple(tuple);
            }
        }
        return output;
    }

    Relation project(vector<int> colsToKeep)
    {
        Relation output; // not pass in something??
        output.setName(name);

        Scheme TempScheme;
        for (unsigned int i = 0; i < colsToKeep.size(); i++)
        {
            TempScheme.pushBack(scheme.at(colsToKeep.at(i)));
        }
        output.setScheme(TempScheme);

        for (auto tuple : tuples)
        {
            Tuple tempTuple;
            for (unsigned j = 0; j < colsToKeep.size(); j++)
            {
                tempTuple.pushBack(tuple.at(colsToKeep.at(j)));
            }
            output.addTuple(tempTuple);
        }
        return output;
    }

    // vvvvv FUNCTION THAT DID NOT WORK
    // Relation project(vector<unsigned int> colsToKeep)
    // {
    //     Relation output(name, scheme, tuples);
    //     map<unsigned int, const string> mapOfSchemeElements;
    //     map<unsigned int, const string> mapOfTuples;
    //     // vector<string> vect{};
    //     output.scheme = Scheme();
    //     // output.tuples.clear();

    //     for (unsigned int i = 0; i < colsToKeep.size(); i++)
    //     {
    //         mapOfSchemeElements.insert({i, scheme.at(i)});
    //     }
    //     for (unsigned int i = 0; i < colsToKeep.size(); i++)
    //     {
    //         output.scheme.pushBack(mapOfSchemeElements[i]);
    //         // for (auto &tuple : tuples)
    //         // {
    //         //     output.addTuple(tuple);
    //         // }
    //     }

    //     //  TODO:: FIGURE OUT HOW TO UPDATE TUPLES!

    //     // for (auto i = mapOfSchemeElements.begin(); i !=mapOfSchemeElements.end(); i++) {
    //     //     if (mapOfSchemeElements[i] == )
    //     // }
    //     // Relation test = output;
    //     return output;
    // }

    // Only updates scheme
    Relation rename(Scheme newNames)
    {
        Relation output(name, tuples);
        Scheme TempScheme;
        output.setScheme(newNames);
        return output;
    }

    unsigned int size()
    {
        return tuples.size();
    }
};