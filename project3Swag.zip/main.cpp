#include <iostream>
#include <istream>
#include <fstream>
#include <vector>
#include <sstream>
#include "token.h"
#include "scanner.h"
#include "parser.h"
#include "predicate.h"
#include "parameter.h"
#include "datalogProgram.h"
#include "Scheme.h"
#include "Tuple.h"
#include "Relation.h"
#include "Database.h"

vector<string> flatten(vector<Parameter> vectorOfParameters)
{
    vector<string> flattenedParameters;
    for (unsigned int i = 0; i < vectorOfParameters.size(); i++)
    {
        flattenedParameters.push_back(vectorOfParameters.at(i).getValue());
    }
    return flattenedParameters;
}

int main(int argc, char *argv[])
{

    if (argc != 2)
    {
        return 1;
    }

    string inputFileName = argv[1];
    ifstream input(inputFileName);
    int realTokenCount = 0;
    vector<Token> tokens;
    if (!input)
    {
        throw runtime_error("Could not open file");
    }
    stringstream buffer;
    buffer << input.rdbuf();
    ofstream outfile;
    string inputString = buffer.str();

    Scanner scanner(inputString);

    while (fileReadCompleted == false)
    {

        realTokenCount++;

        Token currToken = scanner.scanToken();
        if (currToken.getType() != TokenType::COMMENT)
        {
            tokens.push_back(currToken);
        }
    }

    Parser parser(tokens);

    parser.parse();
    datalogProgram dp = parser.getDatalogProgram();
    Database database;

    for (auto &scheme : dp.getSchemes())
    {
        Relation newRelation(scheme.getName(), flatten(scheme.getParameters()));
        database.insert(newRelation);
    }

    for (auto &tuple : dp.getFacts())
    {
        Relation &r = database.getRelationByReference(tuple.getName()); // CHECK:: RelationCOpy or by reference??
        vector<Parameter> parameter = tuple.getParameters();

        Tuple tSwag = Tuple(flatten(parameter));
        r.addTuple(tSwag);
    }

    for (auto &query : dp.getQueries())
    {
        Relation queryEvaluated = database.evaluateQuery(query);

        cout << query.toString() << "? ";

        if (queryEvaluated.size() > 0)
        {
            cout << "Yes(" << queryEvaluated.size() << ")" << endl;
        }

        else
        {
            cout << "No" << endl;
        }

        cout << queryEvaluated.toString();
    }

    // put schemes in as empty relations, with schemeid, and flattened parameters as the scheme.

    // go over the facts & grab the relation that matches the getID, get some parameters

    return 0;
}