#pragma once
#include "datalogProgram.h"
#include "Database.h"
#include "Relation.h"

class Interpreter
{
private:
    datalogProgram program;
    Database database;

public:
    Interpreter(datalogProgram program) : program(program)
    {
    }

    void run()
    {
        evalSchemes();
        evalFacts();
        // evalRules(); IGNORE FOR NOW. Project 4.
        evalQueries();
    }

    void evalSchemes()
    {
        for (Predicate p : program.getSchemes())
        {
            Relation newRelation;
            vector<string> contents;
            for (Parameter param : p.getParameters())
            {
                contents.push_back(param.toString());
            }
            newRelation.setScheme(Scheme(contents));
            newRelation.setName(p.getName()); //           BUGGY?????? CHECK HERE
            database.insert(newRelation);
        }
        // for each scheme s in program.schemes
        //  make a new relation r
        //  make a new scheme newScheme
        //  set name of relation to name of s
        //  for each paramater p in s
        //   push_back p.tostring into newScheme
        //   add newScheme into r
        //  add r to our database
    }

    void evalFacts()
    {
        for (Predicate p : program.getFacts())
        {
            Relation r = database.getRelationByReference(p.getName());
            vector<string> contents;
            for (Parameter param : p.getParameters())
            {
                contents.push_back(param.toString());
            }
            r.addTuple(Tuple(contents));
            database.insert(r);
        }
        // for each fact f in program.facts
        //  get relation r by reference from the database
        //  make a new tuple newTuple
        //  for each paramater p in f
        //   push_back p.tostring into tuple newTuple
        //   add newTuple into r
    }
    // MOVED TO DATABASE vvvvv
    void evalQueries()
    {
        for (Predicate p : program.getQueries())
        {
            Relation r = evaluatePredicate(p);
            cout << r.toString();
        }
    }

    Relation evaluatePredicate(Predicate predicate)
    {
        Relation currentRelation = database.getRelationCopy(predicate.getName());
        vector<unsigned int> columnsToKeep;
        vector<string> names;

        for (unsigned int i = 0; i < predicate.getParameters().size(); i++)
        {
            Parameter currentParameter = predicate.getParameters().at(i);

            if (currentParameter.toString().at(0) == '\'')
            {
                currentRelation = currentRelation.select(i, currentParameter.toString());
            }
            else
            {
                bool seenBefore = false;
                int indexFound = 0;
                // TODO:: Loop that checks through names and if currParam is found set seenBefore to true, set index found to index at which it is seen

                if (seenBefore)
                {
                    currentRelation = currentRelation.select(i, columnsToKeep.at(indexFound)); // FOR SELECT WITH TWO INTS
                }

                else
                {
                    columnsToKeep.push_back(i);
                    names.push_back(currentParameter.toString());
                }
            }
        }

        // project(columnsToKeep);
        // rename(names);
        return currentRelation;
    }

    // RUN AN IMPUT AND RUN YOUR DATABASE TOSTRING AND MAKE SURE WHAT GOT PRINTED OUT MATCHES WHAT YOU WERE EXPECTING.
};